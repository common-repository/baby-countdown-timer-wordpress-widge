<?php
/*
Plugin Name:Baby Countdown Timer WP Plugin from TripletsMommy.com
Plugin URI: http://tripletsmommy.com/category/widgets/
Description: Display a Baby Countdown Timer in your Wordpress Sidebar
Version: 1.0
Author: Kerry W Mann Jr.
Author URI: http://tripletsmommy.com/category/widgets/
*/



// Hook for adding admin menus
add_action('admin_menu', 'mt_add_pages3');

// action function for above hook
function mt_add_pages3() {

    // Add a new top-level menu
    add_menu_page('Baby CountDown Timer', 'BabyCountDownTimer', 8, __FILE__, 'mt_toplevel_page3');
}

function mt_toplevel_page3() {
    echo "<div align=\"center\"> <h2>Baby CountDown Timer Generator</h2><p><br />
<div align=\"center\">
	<table border=\"1\" width=\"77%\">
	<tr>
		<td><ol>
	<li>Input a header (i.e.\"Countdown to Baby\") &amp; Input your due date.</li>
	<li>Press the \"Generate Code\" Button</li>
	<li>Highlight all of the generated code in the box. Right click and select \"Copy\" (or Highlight text and press CTRL + C at the same time</li>
	<li>Go to your widget page<a title=\"widget\" href=\"/wp-admin/widgets.php\">here</a>&nbsp;
	(WP Admin--&gt; Design--&gt; Widgets</li>
	<li>Add a TEXT widget to your sidebar- and PASTE your widget code in. (i.e.
	right click and select PASTE or press CTRL + V)</li>
	<i> The image below to the left is just a screenshot- its not a working example)</i><br />
</ol></td>
	</tr>
</table></div>
<br />

<object classid=\"clsid:d27cdb6e-ae6d-11cf-96b8-444553540000\" width=\"400\" height=\"465\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0\"><param name=\"src\" value=\"http://tripletsmommy.com/babycountdown.swf\" /><embed type=\"application/x-shockwave-flash\" width=\"400\" height=\"465\" src=\"http://tripletsmommy.com/babycountdown.swf\"></embed></object>
</div>";


}



?>